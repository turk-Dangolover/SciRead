
<footer class="footer mt-auto py-3 text-center"style="background-color: #f1f1f1;">
    <div class="Container py-3">
        <p>This Website was Build by</p>

        <a href="#" class="d-inline-block">Cem</a>,
        <a href="#" class="d-inline-block">Viktoria</a>,
        <a href="#" class="d-inline-block">Jonas</a>,
        <a href="#" class="d-inline-block">Kevin</a>
    <div>   
</footer>
  