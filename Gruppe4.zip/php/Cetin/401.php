<!--
Erstellt von Cem Cetin
Beschreibung: HTML-Seite für Fehler 401
-->
<body>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <h1>Fehler 401: Unauthorisiert</h1>
                <p>Zugang verweigert.</p>
            </div>
        </div>
    </div>
    <?php
include_once "../Dreessen/footer.php";
?>
</body>
</html>